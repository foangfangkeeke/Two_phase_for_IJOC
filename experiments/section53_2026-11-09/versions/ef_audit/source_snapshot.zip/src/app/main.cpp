#define NOMINMAX

#include "algorithm/feasibility_diagnostics.hpp"
#include "algorithm/lifted_ils.hpp"
#include "algorithm/lifted_two_phase.hpp"
#include "algorithm/natural_ils.hpp"
#include "algorithm/plan_audit.hpp"
#include "config/run_config.hpp"
#include "config/solver_config.hpp"
#include "domain/wireless_data.hpp"
#include "model/extensive_form.hpp"
#include "solver/copt_solver.hpp"

#include <algorithm>
#include <chrono>
#include <cmath>
#include <cstdio>
#include <ctime>
#include <filesystem>
#include <iostream>
#include <iomanip>
#include <stdexcept>
#ifdef _WIN32
#include <fcntl.h>
#include <io.h>
#include <windows.h>
#endif

namespace {

std::string BuildCaseLabel(const RunConfig& config)
{
    std::string scale = config.dataName;
    if (scale == "tower" || scale == "tower_base") scale = "R28";
    else if (scale == "tower_medium") scale = "R12";
    else if (scale == "tower_small") scale = "R3";
    const size_t separator = scale.find('_');
    if (scale.front() == 'R' && separator != std::string::npos) {
        scale = scale.substr(0, separator);
    }
    return scale + "-N" + std::to_string(config.scenarioCount) +
        "-F" + std::to_string(config.dwcTopN) +
        "-C" + std::to_string(config.chargerCapacity);
}

void RedirectOutput(const std::filesystem::path& path)
{
#ifdef _WIN32
    const std::string nativePath = path.string();
    HANDLE handle = CreateFileA(nativePath.c_str(), GENERIC_WRITE, FILE_SHARE_READ,
        nullptr, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, nullptr);
    if (handle == INVALID_HANDLE_VALUE) {
        throw std::runtime_error("Cannot open log file: " + nativePath);
    }
    const int descriptor = _open_osfhandle(reinterpret_cast<intptr_t>(handle), _O_TEXT);
    if (descriptor == -1) {
        CloseHandle(handle);
        throw std::runtime_error("Cannot attach log file: " + nativePath);
    }
    if (_dup2(descriptor, _fileno(stdout)) != 0 ||
        _dup2(descriptor, _fileno(stderr)) != 0) {
        _close(descriptor);
        throw std::runtime_error("Cannot redirect output to log file: " + nativePath);
    }
    _close(descriptor);
#else
    std::freopen(path.string().c_str(), "w", stdout);
    std::freopen(path.string().c_str(), "a", stderr);
#endif
    std::cout.clear();
    std::cerr.clear();
    std::cout << std::unitbuf;
    std::cerr << std::unitbuf;
}

std::filesystem::path StartLog(const RunConfig& config)
{
    const std::string label = BuildCaseLabel(config);
    const std::filesystem::path directory = std::filesystem::path("logs") / label;
    std::filesystem::create_directories(directory);
    const std::time_t now = std::chrono::system_clock::to_time_t(
        std::chrono::system_clock::now());
    std::tm localTime{};
#ifdef _WIN32
    localtime_s(&localTime, &now);
#else
    localtime_r(&now, &localTime);
#endif
    char timestamp[32];
    std::strftime(timestamp, sizeof(timestamp), "%Y-%m-%d_%H-%M-%S", &localTime);
    return directory / (label + "_" + config.algorithm + "_" + config.problem +
        "_" + timestamp + ".log");
}

void PrintRuntimeOptions(const RunConfig& config)
{
    std::cout << "Runtime options: facility_cost_scale=" << config.facilityCostScale
              << ", energy_scale=" << config.energyScale
              << ", battery_step=" << config.batteryCapacityStep
              << ", scenario_count=" << config.scenarioCount
              << ", scenario_start=" << config.scenarioStart
              << ", cap=" << config.chargerCapacity
              << ", dwc_top_n=" << config.dwcTopN
              << ", wireless_option=" << (config.allowWirelessCharging ? 1 : 0)
              << ", rsp=" << (config.useRsp ? 1 : 0)
              << ", rsp_workers=";
    if (config.rspWorkers > 0) std::cout << config.rspWorkers;
    else std::cout << "auto";
    std::cout << ", rsp_threads=";
    if (config.rspThreads > 0) std::cout << config.rspThreads;
    else std::cout << "auto";
    std::cout << ", preprocess_bounds=" << (config.preprocessBounds ? 1 : 0)
              << ", valid_inequality=" << (config.useValidInequality ? 1 : 0)
              << '\n';
}

void PrintInstanceSummary(const wireless::InstanceData& instance)
{
    std::cout << "Instance: data=" << instance.name << ", scenario_folders=";
    for (size_t index = 0; index < instance.scenarios.size(); ++index) {
        if (index != 0) std::cout << ';';
        std::cout << instance.scenarios.at(index).descriptor.folder;
    }
    std::cout << ", battery_range=[" << instance.operation.minimumBatteryCapacity
              << ',' << instance.operation.maximumBatteryCapacity << "]\n";
}

void PrintAlgorithmStatus(const RunConfig& config, const solver::Result& result)
{
    std::cout << "Algorithm termination: algorithm=" << config.algorithm
              << ", status=" << solver::ToString(result.status)
              << ", has_solution=" << result.hasSolution
              << ", UB=" << result.objective
              << ", LB=" << result.bound
              << ", gap_percent=";
    if (result.hasSolution && std::isfinite(result.objective) &&
        std::isfinite(result.bound)) {
        std::cout << (result.objective - result.bound) /
            std::max(1.0, std::fabs(result.objective)) * 100.0;
    } else {
        std::cout << "inf";
    }
    std::cout << ", reported_seconds=" << result.seconds << '\n';
}

} // namespace

int main(int argc, char* argv[])
{
    try {
        std::cout << std::fixed << std::setprecision(6);
        const ParsedCommandLine commandLine = ParseCommandLine(argc, argv);
        if (commandLine.showHelp) {
            PrintUsage();
            return 0;
        }
        if (commandLine.config.algorithm != "data-check" &&
            commandLine.config.algorithm != "no-dwc-feasibility" &&
            commandLine.config.algorithm != "ef" &&
            commandLine.config.algorithm != "natural-ils" &&
            commandLine.config.algorithm != "lifted-ils" &&
            commandLine.config.algorithm != "lifted-two-phase" &&
            commandLine.config.algorithm != "full" &&
            commandLine.config.algorithm != "plan-audit") {
            throw std::invalid_argument("Algorithm is not implemented on the rewrite branch yet: " +
                commandLine.config.algorithm);
        }

        const SolverConfig solver = LoadSolverConfig();
        const std::filesystem::path logPath = StartLog(commandLine.config);
        std::cout << "Log file: " << logPath.string() << std::endl;
        RedirectOutput(logPath);
        if (commandLine.config.algorithm == "plan-audit") {
            std::cout << "Execution policy: version=section53-fixed-plan-audit-2026-11-09, "
                      << "fixed_design=1, original_optimization_bounds=source_log_only\n";
        } else {
            std::cout << "Execution policy: version=final-rsp-skip-2026-11-05, "
                      << "rsp_numerical=skip_screening, original_subproblem=required\n";
        }
        PrintRuntimeOptions(commandLine.config);
        std::cout << "Solver options: mip_gap=" << solver.mipGap
                  << ", global_gap=" << solver.globalGap
                  << ", time_limit=" << solver.timeLimit
                  << ", threads=" << solver.threads << '\n';
        const wireless::InstanceData instance = wireless::LoadInstance(commandLine.config);
        PrintInstanceSummary(instance);
        if (commandLine.config.algorithm == "plan-audit") {
            wireless::algorithm::AuditFixedPlan(instance, commandLine.config, solver);
            return 0;
        }
        if (commandLine.config.algorithm == "no-dwc-feasibility") {
            const solver::Result result =
                wireless::algorithm::DiagnoseNoDwcFeasibility(
                    instance, commandLine.config, solver);
            return result.hasSolution ? 0 : 1;
        }
        if (commandLine.config.algorithm == "ef") {
            const solver::Result result = wireless::model::SolveExtensiveForm(
                instance, commandLine.config, solver);
            PrintAlgorithmStatus(commandLine.config, result);
            std::cout << "EF status: " << solver::ToString(result.status) << '\n';
            std::cout << "UB: " << result.objective << ", LB: " << result.bound
                      << ", gap=" << result.relativeGap * 100.0 << "%\n";
            std::cout << "EF solve time: " << result.seconds << " s\n";
            return result.status == solver::Status::Optimal ||
                (result.status == solver::Status::TimeLimit && result.hasSolution) ? 0 : 1;
        }

        if (commandLine.config.algorithm == "natural-ils") {
            const solver::Result result = wireless::algorithm::SolveNaturalIls(
                instance, commandLine.config, solver);
            PrintAlgorithmStatus(commandLine.config, result);
            return result.status == solver::Status::Optimal ? 0 : 1;
        }

        if (commandLine.config.algorithm == "lifted-ils") {
            const solver::Result result = wireless::algorithm::SolveLiftedIls(
                instance, commandLine.config, solver);
            PrintAlgorithmStatus(commandLine.config, result);
            return result.status == solver::Status::Optimal ? 0 : 1;
        }

        if (commandLine.config.algorithm == "lifted-two-phase") {
            const solver::Result result = wireless::algorithm::SolveLiftedTwoPhase(
                instance, commandLine.config, solver);
            PrintAlgorithmStatus(commandLine.config, result);
            return result.status == solver::Status::Optimal ||
                result.status == solver::Status::TimeLimit ? 0 : 1;
        }

        if (commandLine.config.algorithm == "full") {
            const solver::Result result = wireless::algorithm::SolveFull(
                instance, commandLine.config, solver);
            PrintAlgorithmStatus(commandLine.config, result);
            return result.status == solver::Status::Optimal ||
                result.status == solver::Status::TimeLimit ? 0 : 1;
        }

        std::cout << "data=" << instance.name
                  << ", scenarios=" << instance.scenarios.size()
                  << ", energy_per_km=" << instance.operation.energyPerKm
                  << ", charger_types=" << instance.chargers.rates.size()
                  << ", time_limit=" << solver.timeLimit << '\n';
        for (size_t index = 0; index < instance.scenarios.size(); ++index) {
            const auto& scenario = instance.scenarios[index];
            std::cout << "scenario=" << index
                      << ", folder=" << scenario.descriptor.folder
                      << ", probability=" << scenario.descriptor.probability
                      << ", buses=" << scenario.schedule.busIds.size()
                      << ", routes=" << scenario.schedule.routeNames.size()
                      << ", trips=" << scenario.schedule.stationsByTrip.size()
                      << ", stations=" << scenario.network.stations.size()
                      << ", plug_in_stations=" << scenario.network.plugInStations.size()
                      << '\n';
        }
        return 0;
    } catch (const std::exception& error) {
        std::cerr << "Error: " << error.what() << '\n';
        return 1;
    }
}
