#include "solver/copt_solver.hpp"

#include <algorithm>
#include <atomic>
#include <chrono>
#include <cmath>
#include <cstdlib>
#include <filesystem>
#include <iomanip>
#include <iostream>
#include <mutex>
#include <sstream>
#include <stdexcept>

namespace solver {

namespace {

std::atomic<unsigned long long> solveSequence{0};
std::mutex traceMutex;

void Trace(const std::string& message)
{
    const std::lock_guard<std::mutex> lock(traceMutex);
    std::cerr << message << std::endl;
}

} // namespace

Envr CreateEnvironment()
{
    static std::atomic<bool> bannerShown{false};
    if (!bannerShown.exchange(true)) return Envr();

    EnvrConfig config;
    config.Set("nobanner", "1");
    return Envr(config);
}

void Configure(Model& model, const SolverConfig& config, bool enableLog)
{
    model.SetIntParam(COPT_INTPARAM_LOGTOCONSOLE, enableLog ? 1 : 0);
    model.SetDblParam(COPT_DBLPARAM_RELGAP, config.mipGap);
    model.SetDblParam(COPT_DBLPARAM_FEASTOL, 1e-6);
    model.SetDblParam(COPT_DBLPARAM_DUALTOL, 1e-6);
    model.SetDblParam(COPT_DBLPARAM_INTTOL, 1e-5);
    model.SetDblParam(COPT_DBLPARAM_TIMELIMIT, config.timeLimit);
    model.SetIntParam(COPT_INTPARAM_THREADS, config.threads);
    if (config.presolve >= 0) model.SetIntParam(COPT_INTPARAM_PRESOLVE, config.presolve);
    if (config.method >= 0) model.SetIntParam(COPT_INTPARAM_LPMETHOD, config.method);
}

Result Solve(Model& model)
{
    const auto sequence = ++solveSequence;
    const std::string name = model.GetName();
    const char* diagnosticDirectory = std::getenv("WIRELESS_DIAGNOSTIC_DIR");
    if (diagnosticDirectory == nullptr) {
        throw std::runtime_error("WIRELESS_DIAGNOSTIC_DIR is required for this diagnostic build");
    }
    {
        std::ostringstream line;
        line << "SOLVE_TRACE BEGIN id=" << sequence << " model=" << name
             << " time_limit=" << model.GetDblParam(COPT_DBLPARAM_TIMELIMIT)
             << " threads=" << model.GetIntParam(COPT_INTPARAM_THREADS);
        Trace(line.str());
    }
    const auto start = std::chrono::steady_clock::now();
    model.Solve();
    const auto finish = std::chrono::steady_clock::now();

    Result result;
    result.seconds = std::chrono::duration<double>(finish - start).count();
    const int nativeStatus = model.GetIntAttr(COPT_INTATTR_STATUS);
    if (nativeStatus == COPT_STATUS_OPTIMAL) result.status = Status::Optimal;
    else if (nativeStatus == COPT_STATUS_INFEASIBLE) result.status = Status::Infeasible;
    else if (nativeStatus == COPT_STATUS_UNBOUNDED || nativeStatus == COPT_STATUS_INF_OR_UNB) {
        result.status = Status::Unbounded;
    } else if (nativeStatus == COPT_STATUS_NUMERICAL) result.status = Status::Numerical;
    else if (nativeStatus == COPT_STATUS_TIMEOUT) result.status = Status::TimeLimit;
    else if (nativeStatus == COPT_STATUS_INTERRUPTED) result.status = Status::Interrupted;
    else if (nativeStatus == COPT_STATUS_MEMLIMIT) result.status = Status::MemoryLimit;
    else std::cerr << "COPT returned unmapped status=" << nativeStatus << '\n';

    result.hasSolution = model.GetIntAttr(COPT_INTATTR_HASSOL) != 0;
    {
        std::ostringstream line;
        line << std::setprecision(17) << "SOLVE_TRACE STATUS id=" << sequence
             << " model=" << name << " native_status=" << nativeStatus
             << " mapped_status=" << ToString(result.status)
             << " has_solution=" << result.hasSolution << " seconds=" << result.seconds;
        Trace(line.str());
    }
    if ((result.status != Status::Optimal && result.status != Status::Infeasible) ||
        (!result.hasSolution && name.find("master") != std::string::npos)) {
        const auto base = std::filesystem::path(diagnosticDirectory) /
            ("solve_" + std::to_string(sequence) + "_" + name);
        model.WriteMps((base.string() + ".mps").c_str());
        model.WriteParam((base.string() + ".par").c_str());
        Trace("SOLVE_TRACE DUMP id=" + std::to_string(sequence) + " base=" + base.string());
    }
    if (result.hasSolution) result.objective = model.GetDblAttr(COPT_DBLATTR_OBJVAL);
    if (result.status == Status::Optimal || result.status == Status::TimeLimit ||
        result.status == Status::Interrupted) {
        result.bound = model.GetDblAttr(COPT_DBLATTR_BESTBND);
    }
    if (result.hasSolution) {
        result.relativeGap = (result.objective - result.bound) /
            std::max(1.0, std::fabs(result.objective));
    }
    Trace("SOLVE_TRACE END id=" + std::to_string(sequence) + " model=" + name);
    return result;
}

std::string ToString(Status status)
{
    switch (status) {
    case Status::Optimal: return "OPTIMAL";
    case Status::Infeasible: return "INFEASIBLE";
    case Status::Unbounded: return "UNBOUNDED";
    case Status::Numerical: return "NUMERICAL";
    case Status::TimeLimit: return "TIME_LIMIT";
    case Status::Interrupted: return "INTERRUPTED";
    case Status::MemoryLimit: return "MEMORY_LIMIT_NATIVE";
    case Status::Unknown: return "UNKNOWN";
    }
    return "UNKNOWN";
}

} // namespace solver
